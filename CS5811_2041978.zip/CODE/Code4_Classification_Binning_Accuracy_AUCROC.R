################ CLASSIFICATION - DECISION TREE##################################

library(dplyr)


#Numnber of bins
numbers_of_bins = 4


#BINNING
clean_crimedata_for_classification<-clean_crimedata%>%mutate(Housing_Price_New_Bins = cut(Housing_Price_New,
                                                                                          breaks = unique(quantile(Housing_Price_New,probs=seq.int(0,1, by=1/numbers_of_bins))),
                                                                                          include.lowest=TRUE))
# TRAINING AND TESTING
clean_crimedata_for_classification <- subset(clean_crimedata_for_classification, select = -c(Housing_Price_New))

n_rows <- nrow(clean_crimedata_for_classification)
training_idx <- sample(n_rows, n_rows * 0.7)
data_train_for_classification <- clean_crimedata_for_classification[training_idx,]
data_test_for_classification <- clean_crimedata_for_classification[-training_idx,]
View(data_train_for_classification)
dim(data_train_for_classification)
``
library(rpart)
library(rpart.plot)

#Model 3 - Variables used from Regression(28 variables)

fit_classification <- rpart(Housing_Price_New_Bins~., data = data_train_for_classification, method = 'class', cp=0.00099)
rpart.plot(fit_classification, extra = 101)
rpart.rules(fit_classification)


#Prediction
Housing_Price_New_Bins_predicted <-predict(fit_classification, data_test_for_classification, type = 'class')


#CONFUSION MATRIX
confusion_matrix <- table(data_test_for_classification$Housing_Price_New_Bins, Housing_Price_New_Bins_predicted)
print("Confusion matrix as below")
print(confusion_matrix)

#ACCURACY
accuracy_Test <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
print(paste("accuracy=",accuracy_Test))

#install.packages('Metrics')

library(Metrics)
accuracy(data_test_for_classification$Housing_Price_New_Bins, Housing_Price_New_Bins_predicted)
install.packages('pROC')
library(pROC)


#AUC -ROC
y_pred<-as.ordered(Housing_Price_New_Bins_predicted)
mauc_roc <-multiclass.roc(data_test_for_classification$Housing_Price_New_Bins, y_pred)
print("AUC ROC=")
print(mauc_roc)
print(paste('Accuracy for test', accuracy_Test))

#PLOT
plot(mauc_roc)
plot(mauc_roc, ylim=c(0,1), print.thres=TRUE, main=paste('AUC:',round(mauc_roc$auc[[1]],2)))
abline(h=1,col='blue',lwd=2)
abline(h=0,col='red',lwd=2)


########################## END OF CLASSIFICATION#####################################