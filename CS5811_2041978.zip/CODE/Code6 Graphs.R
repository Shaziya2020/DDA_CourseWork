#crimeType
boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$Crime_Type, 
        data = Merge_Half_Yearly_Dataset , xlab ='Crime_Type', ylab = "Housing_Price_Paid", main="Crime and Housing")


boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$New_Build, 
        data = Merge_Half_Yearly_Dataset , xlab ='New_Build', ylab = "Housing_Price_Paid", main="Crime and Housing")


boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$Latitude, 
        data = Merge_Half_Yearly_Dataset , xlab ='Latitude', ylab = "Housing_Price_Paid", main="Crime and Housing")


boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$Longitude, 
        data = Merge_Half_Yearly_Dataset , xlab ='Longitude', ylab = "Housing_Price_Paid", main="Crime and Housing")


boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$New_Build, 
        data = Merge_Half_Yearly_Dataset , xlab ='New_Build', ylab = "Housing_Price_Paid", main="Crime and Housing")


boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$Last_Outcome_Category, 
        data = Merge_Half_Yearly_Dataset , xlab ='Last_Outcome_Category', ylab = "Housing_Price_Paid", main="Crime and Housing")

boxplot(Merge_Half_Yearly_Dataset$Housing_Price_Paid ~ Merge_Half_Yearly_Dataset$Property_Type, 
        data = Merge_Half_Yearly_Dataset , xlab ='Property_Type', ylab = "Housing_Price_Paid", main="Crime and Housing")

#CrimeType
ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid_New)) + geom_density(aes(color = Crime_Type)) + 
  labs(x="Crime_Type", Y= "Housing_Price_Paid_Paid", title = "Density plot for Crime Type and Housing Price")

#New_Build
ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid_New)) + geom_density(aes(color = New_Build)) + 
  labs(x="New_Build", Y= "Housing_Price_Paid", title = "Density plot for New_Built and Housing Price")

#Latitude
ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid)) + geom_density(aes(color =Laitude)) + 
  labs(x="Latitude", Y= "Housing_Price_Paid", title = "Density plot for Latitude and Housing Price")


#Longitude 
ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid)) + geom_density(aes(color =Longitude)) + 
  labs(x="Longitude", Y= "Housing_Price_Paid", title = "Density plot for Longitude and Housing Price")


# Last_Outcome_Category
ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid)) + geom_density(aes(color =Last_Outcome_Category) + 
                                                                                labs(x="Last_Outcome_Category", Y= "Housing_Price_Paid", title = "Density plot for Last_Outcome_Category and Housing Price")
                                                                              
                                                                              #Property_Type 
                                                                              ggplot(Merge_Half_Yearly_Dataset, aes(x = Housing_Price_Paid)) + geom_density(aes(color =Property_Type)) + 
                                                                                labs(x="Property_Type", Y= "Housing_Price_Paid", title = "Density plot for Property_Type and Housing Price")