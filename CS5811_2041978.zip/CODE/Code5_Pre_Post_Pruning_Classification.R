############## Pruning the tree
########## cp is set to 0, i.e. the complexity parameter set to zero
######### when cp is set to 0, we are allowing the tree to grow fully

base_model <- rpart(Housing_Price_New_Bins ~ ., data = data_train_for_classification, method = "class",
                    control = rpart.control(cp = 0))

summary(base_model)

#Plot Decision Tree
plot(base_model)

# Examine the complexity plot
printcp(base_model)
plotcp(base_model)

data_test_for_classification$pred <- predict(base_model, data_test_for_classification, type = "class")
base_accuracy <- mean(data_test_for_classification$pred == data_test_for_classification$Housing_Price_New_Bins)

##### in plotcp graph, find the point where error is not further reducing, that would
#### be final cp value

# Grow a tree with minsplit of 100 and max depth of 8
model_preprun <- rpart(Housing_Price_New_Bins ~ ., data = data_train_for_classification, method = "class",
                       control = rpart.control(cp = 0, maxdepth = 8,minsplit = 100))

# Compute the accuracy of the pruned tree
data_test_for_classification$pred <- predict(model_preprun, data_test_for_classification, type = "class")
accuracy_preprun <- mean(data_test_for_classification$pred == data_test_for_classification$Housing_Price_New_Bins)


#####purning
#Postpruning
# Prune the base_model based on the optimal cp value
model_pruned <- prune(base_model, cp = 0.0007 )


# Compute the accuracy of the pruned tree
data_test_for_classification$pred <- predict(model_pruned, data_test_for_classification$pred, type = "class")
accuracy_postprun <- mean(data_test_for_classification$pred == data_test_for_classification$Housing_Price_New_Bins)
data.frame(base_accuracy, accuracy_preprun, accuracy_postprun)
print("Base Accuracy=")
print(base_accuracy)
print("accuracy_preprun=")
print(accuracy_preprun)
print("accuracy_postprun=")
print(accuracy_postprun)

###### Refer the link https://dzone.com/articles/decision-trees-and-pruning-in-r for pruning related information



