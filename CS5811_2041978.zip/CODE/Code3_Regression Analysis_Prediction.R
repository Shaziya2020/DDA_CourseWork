
########  REGRESSION ANALYSIS- -DECISION TREES##############

#Again performed one hot encoding to check the performance 

# SparkR Output
Outlier_V4_SparkOutput <- read.csv('C:/Users/shazi/Desktop/Term2/CS5811 Distributed Data Analysis_Stasha/OneDrive_1_19-03-2021/SparkData/Outlier_v4/Outlier_V4_SDF.csv')
str(Outlier_V4_SparkOutput)
dim(Outlier_V4_SparkOutput)
library("dummies")

# One hot Encoding
df_merge_v5_pca <- dummy.data.frame(
Outlier_V4_SparkOutput, names=c("Crime_Type","Last_Outcome_Category_New","Town", "District", "New_Build", "Property_Type"), sep="_")
str(df_merge_v5_pca)
dim(df_merge_v5_pca)

#Model-1
#33 variables from PCA used  (20% of the 145 variables derived from PCA)
#df_merge_v6_pca_rmv_unncsry <- subset(df_merge_v5_pca, select = c("Crime_Type_Anti-social behaviour","Crime_Type_Burglary","Crime_Type_Violence and sexual offences","Crime_Type_Other theft","Crime_Type_Vehicle crime","District_REDBRIDGE","District_BARKING AND DAGENHAM","District_EALING","District_ENFIELD","District_HACKNEY","District_HARINGEY","District_HARROW","District_HAVERING","District_HILLINGDON","District_HOUNSLOW","District_WALTHAM FOREST","Housing_Price_New","New_Build_Y","Property_Type_F","Town_ENFIELD","Town_GREENFORD","Town_HARROW","Town_HAYES","Town_HOUNSLOW","Town_LONDON","Town_ROMFORD","Town_RUISLIP","Town_UXBRIDGE","Last_Outcome_Category_New_Status update unavailable","Last_Outcome_Category_New_Investigation complete; no suspect identified","Last_Outcome_Category_New_Last Outcome Category Not available", "Latitude", "Longitude"))


#Model -2
#31 variables from PCA-- Variables Longitude and Latitude are dropped 
#df_merge_v6_pca_rmv_unncsry <- subset(df_merge_v5_pca, select = c("Crime_Type_Anti-social behaviour","Crime_Type_Burglary","Crime_Type_Violence and sexual offences","Crime_Type_Other theft","Crime_Type_Vehicle crime","District_REDBRIDGE","District_BARKING AND DAGENHAM","District_EALING","District_ENFIELD","District_HACKNEY","District_HARINGEY","District_HARROW","District_HAVERING","District_HILLINGDON","District_HOUNSLOW","District_WALTHAM FOREST","Housing_Price_New","New_Build_Y","Property_Type_F","Town_ENFIELD","Town_GREENFORD","Town_HARROW","Town_HAYES","Town_HOUNSLOW","Town_LONDON","Town_ROMFORD","Town_RUISLIP","Town_UXBRIDGE","Last_Outcome_Category_New_Status update unavailable","Last_Outcome_Category_New_Investigation complete; no suspect identified","Last_Outcome_Category_New_Last Outcome Category Not available"))


#Model -3
#28--- crime appears in tree good one cp=0.0008
df_merge_v6_pca_rmv_unncsry <- subset(df_merge_v5_pca, select = c("Crime_Type_Anti-social behaviour","Crime_Type_Burglary","Crime_Type_Violence and sexual offences","Crime_Type_Other theft","Crime_Type_Vehicle crime","District_REDBRIDGE","District_BARKING AND DAGENHAM","District_EALING","District_ENFIELD","District_HACKNEY","District_HARINGEY","District_HAVERING","District_WALTHAM FOREST","Housing_Price_New","New_Build_Y","Property_Type_F","Town_ENFIELD","Town_GREENFORD","Town_HARROW","Town_HAYES","Town_HOUNSLOW","Town_LONDON","Town_ROMFORD","Town_RUISLIP","Town_UXBRIDGE","Last_Outcome_Category_New_Status update unavailable","Last_Outcome_Category_New_Investigation complete; no suspect identified","Last_Outcome_Category_New_Last Outcome Category Not available"))



#path <- '/home/shazi/Downloads/finalsparkRoutput.csv'
#crimedata <-read.csv(path)
crimedata <-df_merge_v6_pca_rmv_unncsry
head(crimedata)
str(crimedata)
shuffle_index <- sample(1:nrow(crimedata))
head(shuffle_index)

crimedata <- crimedata[shuffle_index, ]
head(crimedata)


library(dplyr)
library(magrittr)
library(data.table)
# Drop variables

#clean_crimedata <- subset(crimedata, select = -c(Town_TEDDINGTON,Housing_Price,Longitude,Latitude))
clean_crimedata <- subset(crimedata)
n_rows <- nrow(clean_crimedata)
training_idx <- sample(n_rows, n_rows * 0.7)
data_train_for_regression <- clean_crimedata[training_idx,]
data_test_for_regression <- clean_crimedata[-training_idx,]
dim(data_train_for_regression)


#install.packages("rpart.plot")
summary(clean_crimedata$Housing_Price_New)


library(rpart)
library(rpart.plot)

#Train the Model
fit_for_regression <- rpart(Housing_Price_New~., data = data_train_for_regression, method = 'anova', cp= 0.0008)
rpart.plot(fit_for_regression, extra = 100)

#Pruning
printcp(fit_for_regression)
plotcp(fit_for_regression)
rpart.rules(fit_for_regression)

#summary(fit_for_regression)
text(fit_for_regression)
rsq.rpart(fit_for_regression)
text(fit_for_regression,pretty=4)

printcp(fit_for_regression)
plotcp(fit_for_regression)
rpart.rules(fit_for_regression)
fit_for_regression$cptable[which.min(fit_for_regression$cptable[,"xerror"]),"CP"]

par(mfrow=c(1,2)) # two plots on one page
rsq.rpart(fit_for_regression) # visualize cross-validation results  

# prune the tree
pfit<- prune(fit_for_regression, cp=0.02770389) # from cptable


#install.packages('Metrics')
library(Metrics)
predicted_housing_price<-predict(fit_for_regression, data_test_for_regression)

#MAE
mae_metric<-mae(data_test_for_regression$Housing_Price_New,predicted_housing_price)
print(paste("MAE metric mean absolute error=",mae_metric))

#MAPE
mape_metric<-mape(data_test_for_regression$Housing_Price_New,predicted_housing_price)
print(paste("MAPE metric mean absolute percentage error=",mape_metric))

#RMSE
rmse_metric<-rmse(data_test_for_regression$Housing_Price_New,predicted_housing_price)
print(paste("RMSE metric Root Mean Square Error=",rmse_metric))

#MSE
mse_metric<-mse(data_test_for_regression$Housing_Price_New,predicted_housing_price)	
print(paste("MSE metric Mean Square Error=",mse_metric))	


#Prediction
Predict_Variance_Test=sum((data_test_for_regression$Housing_Price_New-predicted_housing_price)^2)
Actual_Variance_Test=sum((mean(data_test_for_regression$Housing_Price_New) - data_test_for_regression$Housing_Price_New) ^ 2)
R2_Test = 1- Predict_Variance_Test/Actual_Variance_Test
print("R square test=")
print(R2_Test)

########################## END OF REGRESSION#############################################